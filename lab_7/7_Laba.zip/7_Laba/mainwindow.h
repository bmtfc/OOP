#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "array.h"
#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private slots:
    void on_sizeOK_clicked();

    void on_scalarOK_clicked();

    void on_changingOK_clicked();

    void on_elementsOK_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

    void on_accessOK_clicked();

    void on_btn_Max_clicked();

    void on_btn_Min_clicked();

    void on_btn_Average_clicked();

    void on_btn_Decrease_clicked();

    void on_btn_Increase_clicked();

    void on_btn_Multiply_clicked();

    void on_btn_ChangeSize_clicked();

    void on_plus_clicked();

    void on_minusSubstract_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
