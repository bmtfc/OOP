#ifndef ARRAY_H
#define ARRAY_H
#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QListWidget>
#include <QTableWidget>
#include <QPlainTextEdit>
extern int arSize;
extern int arScalar;
extern int arChangeSize;

class Array
{
    int m_iSizeOfArray;
    double *m_dblArray;
public:
   double m_dblResult;
    Array();
    Array(int Size);
    Array(double *elArray, int Size);
    Array(const Array &other);
    ~Array();
    Array& operator=(const Array &other);
    double dblMaxEl();
    double dblMinEl();
    double dblFindAver();
    void m_DecreasingSort();
    void m_IncreasingSort();
    void m_ChangeSize(int iN);
    void operator*(int iScalar);
    void operator+();
    void operator-();
    double& operator[](int iN);
    //--------------------------------------------------------------------------------
    friend void operator<<(QListWidget *widget,Array &el){
        widget->clear();
        for(int i=0; i<arSize;i++){
            QString item=QString::number(el[i]);
            widget->addItem(item);
        }
    }
    //--------------------------------------------------------------------------------
    friend void operator<<(QTableWidget *widget, Array &el){
        widget->setRowCount(1);
        widget->setColumnCount(arSize);
        for(int i=0;i<widget->rowCount();++i){
            for(int j=0;j<widget->columnCount();++j){
                QString item=QString::number(el[j]);
                QTableWidgetItem *isItem=new QTableWidgetItem(item);
                widget->setItem(i,j,isItem);
            }
        }
    }
    //--------------------------------------------------------------------------------
    friend void operator<<(QPlainTextEdit*edit, Array &el){
        QString str;
        for(int i=0; i<arSize; ++i){
            str+=QString::number(el[i]);
            str+=" ";
        }
        edit->setPlainText(str);
    }
    //--------------------------------------------------------------------------------
    void operator>> (QTableWidget *widget);
    void operator>> (QListWidget *widget);
    double* dblGetArray();
    void setArray(double*arr, int Size);
    int sGetSizeOfArray();

};

#endif // ARRAY_H
