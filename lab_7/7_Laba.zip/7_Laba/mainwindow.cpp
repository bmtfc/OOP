#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "array.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
Array *arrElements;

void MainWindow::on_sizeOK_clicked()
{
    int s;
       s = ui->enterSizeOfArray->text().toInt();
       ui->tableInputeWidget->setRowCount(1);
       ui->tableInputeWidget->setColumnCount(s);

       arSize = s;
       for (int i = 0 ; i < ui->tableInputeWidget->rowCount(); i++)
       {
             for(int j = 0; j < ui->tableInputeWidget->columnCount(); j++)
               {
                   QTableWidgetItem *itm = new QTableWidgetItem(tr("%1").arg(0));
                   ui->tableInputeWidget->setItem(i, j, itm);
               }
       }

       arrElements = new Array(arSize);
       ui->listInputWidget->clear();
       for(int i = 0; i < arSize; ++i)
       {
           QListWidgetItem *itm = new QListWidgetItem(tr("%1").arg(0));
           ui->listInputWidget->addItem(itm);
       }

}

void MainWindow::on_scalarOK_clicked()
{
    arScalar = ui->enterScalar->text().toInt();
}

void MainWindow::on_changingOK_clicked()
{
     arChangeSize = ui->enterChangingSize->text().toInt();
}

void MainWindow::on_elementsOK_clicked()
{
    double num;
    num = ui->enterElementsOfArray->text().toDouble();
if(ui->listInputWidget->currentItem()){
    QListWidgetItem *itm = ui->listInputWidget->currentItem();
    itm->setText(QString::number(num));
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    Array *res = new Array(arSize);
    *res >> ui->listInputWidget;
    arrElements = new Array(res->dblGetArray(), arSize);
    ui->tableInputeWidget << *res;
}

void MainWindow::on_pushButton_clicked()
{
    Array *res = new Array(arSize);
    *res >> ui->tableInputeWidget;
    arrElements = new Array(res->dblGetArray(), arSize);
    ui->listInputWidget << *res;
}

void MainWindow::on_accessOK_clicked()
{
    Array *access = new Array(arrElements->dblGetArray(), arSize);
    int i = ui->accessLineEdit->text().toInt();
    double *array = access->dblGetArray();
    double number = array[i];
    int max = arSize;
    if(i < max && i >= 0)
    {
        ui->acessLabel->setText(QString::number(number));
    } else
    {
       ui->acessLabel->setText(QString("FALSE"));
    }
}

void MainWindow::on_btn_Max_clicked()
{
    Array *max_Res = new Array(arrElements->dblGetArray(), arSize);
    ui->MainResultLabel->setText(QString::number(max_Res->dblMaxEl()));
}

void MainWindow::on_btn_Min_clicked()
{
    Array *min_Res = new Array(arrElements->dblGetArray(), arSize);
    ui->MainResultLabel->setText(QString::number(min_Res->dblMinEl()));
}

void MainWindow::on_btn_Average_clicked()
{
    Array *average_Res = new Array(arrElements->dblGetArray(), arSize);
    ui->MainResultLabel->setText(QString::number(average_Res->dblFindAver()));
}

void MainWindow::on_btn_Decrease_clicked()
{
    Array *decreas_Res = new Array(*arrElements);
        decreas_Res->m_DecreasingSort();
        ui->tableOutput << *decreas_Res;
        ui->listOutput << *decreas_Res;
        ui->memoOutput << *decreas_Res;
}

void MainWindow::on_btn_Increase_clicked()
{
    Array *icrease_Res = new Array(*arrElements);
        icrease_Res->m_IncreasingSort();
        ui->tableOutput << *icrease_Res;
        ui->listOutput << *icrease_Res;
        ui->memoOutput << *icrease_Res;
}

void MainWindow::on_btn_Multiply_clicked()
{
    Array *scalar_Res = new Array(arrElements->dblGetArray(), arSize);
    *scalar_Res * arScalar;
    ui->tableOutput << *scalar_Res;
    ui->listOutput << *scalar_Res;
    ui->memoOutput << *scalar_Res;
}


void MainWindow::on_btn_ChangeSize_clicked()
{
    Array *change_Res = new Array(*arrElements);
        change_Res->m_ChangeSize(arChangeSize);
        double *arr = change_Res->dblGetArray();
        ui->tableOutput->setRowCount(1);
        ui->tableOutput->setColumnCount(arChangeSize);
        ui->tableInputeWidget->setRowCount(1);
        ui->tableInputeWidget->setColumnCount(arChangeSize);
        for (int i = 0 ; i < ui->tableOutput->rowCount(); i++)
        {
            for(int j = 0; j < arChangeSize; j++)
            {

                if(arSize > j)
                {
                    QTableWidgetItem *itm = new QTableWidgetItem(tr("%1").arg(arr[j]));
                    ui->tableOutput->setItem(i, j, itm);
                     ui->tableInputeWidget->setItem(i, j, itm);
                } else
                {
                    QTableWidgetItem *itm = new QTableWidgetItem(tr("%1").arg(0));
                    ui->tableOutput->setItem(i, j, itm);
                     ui->tableInputeWidget->setItem(i, j, itm);
                }
            }
        }
        ui->listOutput->clear();
        for(int i = 0; i < arChangeSize; ++i)
        {
            if(arSize > i)
            {
            QListWidgetItem *itm = new QListWidgetItem(tr("%1").arg(arr[i]));
            ui->listOutput->addItem(itm);
            } else
            {
                QListWidgetItem *itm = new QListWidgetItem(tr("%1").arg(0));
                ui->listOutput->addItem(itm);
            }
        }

        QString str;
}
void MainWindow::on_plus_clicked()
{
    Array *adding_Res = new Array(arrElements->dblGetArray(), arSize);
        +*adding_Res;
        ui->MainResultLabel->setText(QString::number(adding_Res->m_dblResult));
}

void MainWindow::on_minusSubstract_clicked()
{
    Array *difference_Res = new Array(arrElements->dblGetArray(), arSize);
        -*difference_Res;
        ui->MainResultLabel->setText(QString::number(difference_Res->m_dblResult));
}
