#include "array.h"
int arSize;
int arScalar;
int arChangeSize;
//--------------------------------------------------------------------------------
Array::Array()
{
m_dblArray=0;
}
//--------------------------------------------------------------------------------
Array::Array(int Size){
    m_iSizeOfArray = Size;
    m_dblArray = new double [m_iSizeOfArray];
    for(int i=0; i<m_iSizeOfArray;i++){
        m_dblArray[i]=0;
    }
}
Array::Array(double *elArray, int Size){
    m_iSizeOfArray = Size;
    m_dblArray = new double [m_iSizeOfArray];
    for(int i=0; i<m_iSizeOfArray;i++){
        m_dblArray[i]=elArray[i];
    }
}

Array::Array(const Array &other){
    this->m_iSizeOfArray=other.m_iSizeOfArray;
    this->m_dblArray=new double [other.m_iSizeOfArray];
    for (int i=0;i< m_iSizeOfArray;i++){
        this->m_dblArray[i]=other.m_dblArray[i];
    }

}

Array::~Array(){
    delete [] m_dblArray;
}

Array& Array::operator=(const Array &other){
    if(this->m_dblArray!= nullptr){
        delete [] this->m_dblArray;
    }
    this->m_iSizeOfArray=other.m_iSizeOfArray;
    m_dblArray=new double[other.m_iSizeOfArray];
    for (int i=0;i<m_iSizeOfArray;i++){
        this->m_dblArray[i]=other.m_dblArray[i];
    }
    return *this;
}
//--------------------------------------------------------------------------------
void Array:: operator*(int iScalar){
    for(int i=0; i<arSize;i++){
        this->m_dblArray[i]=this->m_dblArray[i]*iScalar;
    }
}
//--------------------------------------------------------------------------------
void Array:: operator+(){
    this->m_dblResult=0;
    for(int i=0; i<arSize; i++){
        this->m_dblResult=this->m_dblResult+this->m_dblArray[i];
    }
}
//--------------------------------------------------------------------------------
void Array:: operator-(){
    this->m_dblResult=this->m_dblArray[0];
    for(int i=1; i< arSize; ++i){
    this->m_dblResult=this->m_dblResult-this->m_dblArray[i];
    }
}
//--------------------------------------------------------------------------------
double& Array::operator[](int iN){
    return m_dblArray[iN];
}
//--------------------------------------------------------------------------------
void Array:: operator>>(QTableWidget*widget){
    for(int i=0; i<widget->rowCount();++i){
        for(int j=0; j<widget->columnCount();++j){
            this->m_dblArray[j]=widget->item(i,j)->text().toDouble();
        }
    }
}
//--------------------------------------------------------------------------------
void Array:: operator>>(QListWidget*widget){
    for(int i=0; i<this->m_iSizeOfArray;++i){
        this->m_dblArray[i]=widget->item(i)->text().toDouble();
    }
}
//--------------------------------------------------------------------------------
double* Array:: dblGetArray(){
    double*arr=this->m_dblArray;
    return arr;
}
//--------------------------------------------------------------------------------
int Array:: sGetSizeOfArray(){
    return this->m_iSizeOfArray;
}
//--------------------------------------------------------------------------------
void Array:: setArray(double *arr, int Size){
    for(int i=0; i<Size; ++i){
        m_dblArray[i]=arr[i];
    }
}
//--------------------------------------------------------------------------------
double Array:: dblMaxEl(){
    double max = this->m_dblArray[0];
    for(int i = 1; i < this->m_iSizeOfArray; i++)
        {
            if(max < this->m_dblArray[i])
                {
                    max = this->m_dblArray[i];
                }
        }
return  max;
}
//--------------------------------------------------------------------------------
double Array:: dblMinEl(){
    double min = this->m_dblArray[0];
    for(int i = 1; i < this->m_iSizeOfArray; i++)
        {
            if(min > this->m_dblArray[i])
                {
                    min = this->m_dblArray[i];
                }
        }
return  min;
}
//--------------------------------------------------------------------------------
double Array:: dblFindAver(){
    double avrg = 0 ;
    for(int i = 0; i < this->m_iSizeOfArray; ++i)
    {
        avrg += this->m_dblArray[i];
    }
    return avrg/this->m_iSizeOfArray;
}
//--------------------------------------------------------------------------------
void Array:: m_DecreasingSort(){
    for(int i = 0; i < (m_iSizeOfArray - 1); i++)
       {
           int min = i;
           for(int j = (i + 1); j < m_iSizeOfArray; j++)
           {
               if(m_dblArray[j] > m_dblArray[min])
               {
                   min = j;
               }
           }
           double temp = m_dblArray[min];
           m_dblArray[min] = m_dblArray[i];
           m_dblArray[i] = temp;
        }
}
//--------------------------------------------------------------------------------
void Array:: m_IncreasingSort(){
    int swaps;
        //swap>0
        do
        {
            swaps = 0;
            for(int i = 0; i < (m_iSizeOfArray-1); i++)
            {
                if(m_dblArray[i] > m_dblArray[i + 1])
                {
                    int temp = m_dblArray[i];
                    m_dblArray[i] = m_dblArray[i + 1];
                    m_dblArray[i + 1] = temp;
                    swaps++;
                }
            }
        }
        while(swaps != 0);
}
//--------------------------------------------------------------------------------
void Array:: m_ChangeSize(int iN){


        for(int i = 0 ; i < iN; ++i)
        {
            m_dblArray[i] = this->m_dblArray[i];
        }

}




